package com.example.nodemcu;

import android.support.annotation.NonNull;
public class ult_values {
    public String distance;

    @NonNull
    @Override
    public String toString() {
        return "DISTANCE :: " + distance;
    }

    public ult_values() {
    }

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }
}