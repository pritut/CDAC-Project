package com.example.nodemcu;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

import java.util.ArrayList;

public class check_solots extends AppCompatActivity {

    ListView listView;
    ArrayList<ult_values>  ultstatus_values = new ArrayList<>();
    ArrayAdapter<ult_values> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_solots);

        listView = findViewById(R.id.listView);
        adapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1, ultstatus_values);
        listView.setAdapter(adapter);
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        loadUltvalues();
    }

    public void loadUltvalues()
    {
        ultstatus_values.clear();

        //String url = "http://172.18.1.39:4000/dist";
        String url = "http://172.18.1.39:4000/dist";

        Ion.with(this)
                .load("GET", url)
                .asJsonArray()
                .setCallback(new FutureCallback<JsonArray>() {
                    @Override
                    public void onCompleted(Exception e, JsonArray result) {

                            ultstatus_values.clear();
                        
                            Log.e("check_solots", result.toString());
                            for(int index = 0; index < result.size(); index++){
                                JsonObject object = result.get(index).getAsJsonObject();
                                ult_values ultstatus_val = new ult_values();

                                //((ult_values) ultstatus_val).setDistance(object.get("distance").toString());
                                ultstatus_val.setDistance(object.get("value").getAsString());

                                ultstatus_values.add(ultstatus_val);
                            }

                            adapter.notifyDataSetChanged();
                    }
                });

    }

}













